const router = require("express").Router();
const ESG = require("../models/ESG");


// GET DOMAIN
router.get("/carac/:id", async (req, res) => {
    try {
        console.log( req.params.id);
        if( req.params.id === "623f970fc47e6a2bbf0c9411"){
            console.log( )
            const date = await DATE.findById( req.params.id);
            res.status(200).json( date );
        }
        else{
            const esgArray = await ESG.findById(req.params.id);
            res.status(200).json(esgArray);
        }
    } catch (err) {
        res.status(500).json(err);
    }
});

//GET ALL DOMAINS
router.get("/", async (req, res) => {
    const qNew = req.query.new;
    const qCategory = req.query.cat;
    try {
        let domains;
        
        if(qNew) {
            domains = await ESG.find().sort({createdAt: -1}).limit(1)

        } else if(qCategory) {
            domains = await ESG.find({
                cat: {
                    $in: [qCategory],
                },
            });
        } else {
            domains = await ESG.find();
        }
        res.status(200).json(domains);
    } catch(err) {
        res.status(500).json(err);
    }
});

module.exports = router
